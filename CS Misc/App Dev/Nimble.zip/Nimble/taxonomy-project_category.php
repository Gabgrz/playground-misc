<?php get_header(); ?>

<div id="main-area">
	<div class="container">
		<div id="content-area" class="fullwidth clearfix">
		<?php get_template_part( 'includes/entry', 'portfolio' ); ?>
		</div> <!-- end #content-area -->
	</div> <!-- end .container -->
</div> <!-- end #main-area -->

<?php get_footer(); ?>