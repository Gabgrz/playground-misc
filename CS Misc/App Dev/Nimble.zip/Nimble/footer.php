	<footer id="main-footer">
	<?php get_sidebar( 'footer' ); ?>

		<div id="footer-bottom">
			<div class="container">
				<p id="copyright"><?php printf( __( 'Designed by %1$s | Powered by %2$s', 'Nimble' ), '<a href="http://www.elegantthemes.com" title="Premium WordPress Themes">Elegant Themes</a>', '<a href="http://www.wordpress.org">WordPress</a>' ); ?></p>
			</div> <!-- end .container -->
		</div> <!-- end #footer-bottom -->
	</footer> <!-- end #main-footer -->
<?php wp_footer(); ?>
</body>
</html>