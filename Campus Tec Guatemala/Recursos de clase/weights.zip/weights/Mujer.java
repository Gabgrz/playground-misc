/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weights;

/**
 *
 * @author ap
 */
public class Mujer extends Persona{
    private int tbm;
    
    public Mujer(){
        this.setTbm(10);
    }

    public int getTbm() {
        return tbm;
    }

    public void setTbm(int tbm) {
        this.tbm = tbm;
    }
}
