/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weights;

/**
 *
 * @author ap
 */
public class Planetas {
    private String name;
    private double gravity;
    
    public Planetas(){
        // constructor
    }
    
    protected void setGravity(double value){
        this.gravity = value;
    }
    
    protected void setName(String value){
        this.name = value;
    }
    
    protected double getGravity(){
        return this.gravity;
    }
    
    protected String getName(){
        return this.name;
    }
}
