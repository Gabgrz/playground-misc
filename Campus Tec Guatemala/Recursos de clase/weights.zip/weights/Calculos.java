/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weights;

/**
 *
 * @author ap
 */
public class Calculos {
    public Calculos(){
        // Constructor
    }
    
    public double calcularPeso(double g1, double g2, double peso){
        //Calcula el peso de una persona en otra gravedad
        double weight;
        weight = (g2*peso)/g1;
        
        return weight;
    }
    
    public double IndiceMasaCorporal(){
        return 1.2;
    }
}
