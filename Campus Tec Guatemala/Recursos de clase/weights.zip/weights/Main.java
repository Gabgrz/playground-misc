/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package weights;

import java.util.*;

/**
 *
 * @author ap
 */
public class Main {
    Planetas p1;
    
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Bienvenido a Planet weight y IMC, la aplicacion que calcula pesos en otros planetas");
        System.out.println("Qué quiere hacer?");
        System.out.println("1. Calcular mi peso en otro planeta");
        System.out.println("2. Calcular mi Indice de Masa Corporal");
        
        Scanner entradag = new Scanner(System.in);
        if(entradag.nextInt() == 1){
            calculoEnOtroPlaneta();
        }
        else{
            IMC();
        }
        
        
        
    }
    
    public static void calculoEnOtroPlaneta(){
        System.out.println("Ingrese su nombre");
        Scanner entrada = new Scanner(System.in);
        
        Persona p = new Persona();
        p.setName(entrada.nextLine());
        System.out.println("Ingrese su peso en libras");
 
        p.setPeso(entrada.nextDouble());
        
        System.out.println("En que planeta esta calculado este peso?");
        System.out.println("1. Tierra");
        System.out.println("2. Marte");
        System.out.println("3. Luna");
        
        int planet = entrada.nextInt();
        double g1;
        
        System.out.println("En donde quiere calcular su peso?");
        
        if(planet==1){
            System.out.println("2. Marte");
            System.out.println("3. Luna");
            Planetas t = new Tierra();
            g1 = t.getGravity();
        }
        if(planet==2){
            System.out.println("1. Tierra");
            System.out.println("3. Luna");
            Planetas m = new Marte();
            g1 = m.getGravity();
        }
        if(planet==3){
            System.out.println("2. Marte");
            System.out.println("3. Luna");
            Planetas l = new Luna();
            g1 = l.getGravity();
        }
        else{
            g1 = 1;
        }
        
        int planet2 = entrada.nextInt();
        double g2;
        
        if(planet==planet2){
            System.out.println("No puedes ingresar el mismo planeta de origen y el mismo planeta destino");
        }
        
        if(planet2==1){
            Planetas t2 = new Tierra();
            g2 = t2.getGravity();
        }
        if(planet2==2){
            Planetas m2 = new Marte();
            g2 = m2.getGravity();
        }
        if(planet2==3){
            Planetas l2 = new Luna();
            g2 = l2.getGravity();
        }
        else{
            g2 = 1;
        }
               
        Calculos c = new Calculos();
        double nuevoPeso = c.calcularPeso(g1,g2,p.getPeso());
        
        System.out.println("Su nuevo peso es "+nuevoPeso);
    }
    
    public static void IMC(){
        //funcionalida de calculo de indice de masa corporal
    }
}
