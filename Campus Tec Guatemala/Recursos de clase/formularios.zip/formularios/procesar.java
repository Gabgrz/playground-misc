package formularios;

import javax.swing.JOptionPane;

public class procesar {
    
    String name = "";
    String email = "";
    Integer age = 0;

    public procesar() {
    }
    
    public void capturarDatos(){
        name = ventana.nombre.getText();
        email = ventana.email.getText();
        age = Integer.parseInt(ventana.edad.getText());
    }
    
    public void imprimirDatos(){
        JOptionPane.showMessageDialog(null, "El nombre capturado es: "+name+" "
                + "\nLa edad capturada es: "+age+" "
                + "\nEl email capturado es: "+email, "Mensaje", JOptionPane.PLAIN_MESSAGE);
    }
    
}
