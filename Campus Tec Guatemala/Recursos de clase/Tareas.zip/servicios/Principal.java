/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicios;

import java.sql.Connection;
import java.sql.SQLException;
import modelos.Conexion;
import modelos.Tarea;

/**
 *
 * @author ap
 */
public class Principal {
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        System.out.println("ola");
        Tareas_servicios ts = new Tareas_servicios();

        Tarea t = new Tarea();
        t.setTitulo("tarea desde java");
        t.setDescripcion("La descripcion de la tarea");
        t.setNivel_de_prioridad(1);
        
        ts.guardar(Conexion.obtener(), t);
    }
}
