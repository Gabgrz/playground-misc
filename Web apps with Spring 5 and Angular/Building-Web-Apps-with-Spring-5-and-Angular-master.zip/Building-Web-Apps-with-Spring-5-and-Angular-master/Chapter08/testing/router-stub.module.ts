import {NgModule} from '@angular/core';
import {RouterLinkStubDirective} from './router-stubs';

@NgModule({
    imports:      [],
    declarations: [ RouterLinkStubDirective],
})
export class RouterStubModule { }
