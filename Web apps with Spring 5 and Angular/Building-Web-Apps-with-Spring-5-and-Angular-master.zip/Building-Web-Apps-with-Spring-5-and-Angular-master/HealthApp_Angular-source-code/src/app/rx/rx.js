"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Rx = (function () {
    function Rx() {
    }
    return Rx;
}());
exports.Rx = Rx;
var RxStatus = (function () {
    function RxStatus() {
        this.code = '';
        this.message = '';
    }
    return RxStatus;
}());
exports.RxStatus = RxStatus;
//# sourceMappingURL=rx.js.map