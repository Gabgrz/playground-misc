package com.book.healthapp.repositories;

import org.springframework.data.repository.CrudRepository;

import com.book.healthapp.domain.HealthCentre;

public interface HealthCentreDAO  {

}
