mysql -u root -proot < dbsetup.sql
mvn spring-boot:run
